import express from 'express';
import cors from 'cors';
import db from './database/db.js'; // Conexión a la base de datos
import clienteRoutes from './routes/clienteRoutes.js';


// Crear la aplicación
const app = express();

// Configuración de la aplicación
app.use(cors());
app.use(express.json());

// Probar conexión a la base de datos
try {
    await db.authenticate(); // Cambiado a `db` en lugar de `sequelize`
    console.log('Conexión con la base de datos establecida correctamente.');
} catch (error) {
    console.error('No se pudo conectar a la base de datos:', error);
}

// Rutas
app.use('/estudiantes', clienteRoutes); // Rutas de estudiantes


// Ruta base
app.get('/', (req, res) => {
    res.send('Bienvenido al back-end de Alumnos versión 1.0');
});

// Puerto donde se ejecuta el servicio de la aplicación
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor está funcionando en: http://localhost:${PORT}`);
});
