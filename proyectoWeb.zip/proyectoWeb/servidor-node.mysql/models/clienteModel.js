import { DataTypes } from 'sequelize';
import db from '../database/db.js';  // Importa la instancia de sequelize

const EstudianteModel = db.define('Estudiante', {
    nombreEst: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    apellidoPatEst: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    apellidoMatEst: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    domicilioEst: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    ciudadEst: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    telefonoEst: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    correoEst: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    controlEst: {
        type: DataTypes.STRING,
        allowNull: false,
    }
}, {
    tableName: 'Estudiantes', // Asegúrate de que el nombre de la tabla sea correcto
    timestamps: false, // Si no tienes los campos 'createdAt' y 'updatedAt', puedes desactivar los timestamps
});

export default EstudianteModel;
